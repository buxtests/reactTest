import "./App.css";

function App() {
  return (
    <div className="App">
      <div className="container">
        <div className="placeholder">
          Replace this div with your Carousel component
        </div>
      </div>
    </div>
  );
}

export default App;
